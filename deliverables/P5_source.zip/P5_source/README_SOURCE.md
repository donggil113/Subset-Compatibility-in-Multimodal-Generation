# P5 manuscript source (v5, source commit 67b9e62)

Contents: paper/main.tex, paper/fig_numerics.tex, paper/references.bib, paper/generated/ (tables, numeric macros and figure data generated from committed raw results), paper/claims.csv, paper/build_log_summary.json, BUILD.md, fetch_style.sh.

Not included: the official ICML 2026 style files (no redistribution licence). Run `sh fetch_style.sh` to download them from the official URL with a SHA-256 check, then follow BUILD.md. The build used: pdflatex -interaction=nonstopmode -halt-on-error main.tex; bibtex main; pdflatex (x2), with TeX Live 2026 (pdfTeX 1.40.29). The committed PDF (paper/main.pdf at 67b9e62; sha256 588b9ba5601456c2c715d42a2416bd8af6e986052532a2f226bf4e232b5a82fb) was built from exactly these files.
