# P5 manuscript source (v6, source commit d9c573c)

Contents: paper/main.tex, paper/fig_numerics.tex, paper/references.bib, paper/generated/ (tables, numeric macros and figure data generated from committed raw results), paper/claims.csv, paper/build_log_summary.json, BUILD.md, fetch_style.sh.

Not included: the official ICML 2026 style files (no redistribution licence). Run `sh fetch_style.sh` to download them from the official URL with a SHA-256 check, then follow BUILD.md. The build used: pdflatex -interaction=nonstopmode -halt-on-error -no-shell-escape main.tex; bibtex main; pdflatex (x3; repeated until no 'Rerun' warning), with TeX Live 2026 (pdfTeX 1.40.29). The committed PDF (paper/main.pdf at d9c573c; sha256 531bc269e8347a15611176bba9ac14c034250cb97d57d6e8c5eecb760ba6f367) was built from exactly these files.
